<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-6 mx-auto">
            <div class="card mt-3">
                <div class="card-body">
                    <h4 class="text-center">Jadwal Ibadah</h4>
                    <div class="mt-3">
                        <?php $__currentLoopData = $ibadahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ibadah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('ibadah.show', $ibadah)); ?>" class="btn btn-primary btn-block">
                                Jadwal Ibadah <?php echo e($ibadah->nama); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\x\htdocs\gmahkbni\resources\views/ibadah/index.blade.php ENDPATH**/ ?>