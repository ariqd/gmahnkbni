<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-6 mx-auto py-3">
            <h3 class="text-center">GEREJA MASEHI ADVENT HARI KETUJUH <br> SIDANG BUKTI NUSA INDAH</h3>
            <div class="card card-body mt-3">
                <h4 class="text-center">Lihat Jadwal</h4>
                <div class="row mt-3">
                    <div class="col-6">
                        <a href="#" class="btn btn-primary btn-block">
                            Lihat Jadwal Ibadah
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="#" class="btn btn-primary btn-block">
                            Lihat Jadwal Partisipan
                        </a>
                    </div>
                </div>
            </div>
            <div class="card card-body mt-3">
                <h4 class="text-center">Ubah Jadwal</h4>
                <div class="row mt-3">
                    <div class="col-6">
                        <a href="#" class="btn btn-secondary btn-block">
                            Ubah Jadwal Ibadah
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="#" class="btn btn-secondary btn-block">
                            Ubah Jadwal Partisipan
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\x\htdocs\gmahkbni\resources\views/index-login.blade.php ENDPATH**/ ?>