<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-6 mx-auto py-3">
            <div class="card card-body">
                <h4 class="text-center">Lihat Jadwal</h4>
                <div class="row mt-3">
                    <div class="col-6">
                        <a href="<?php echo e(route('ibadah.index')); ?>" class="btn btn-primary btn-block">
                            Lihat Jadwal Ibadah
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="#" class="btn btn-primary btn-block">
                            Lihat Jadwal Partisipan
                        </a>
                    </div>
                </div>
            </div>
            <?php if(auth()->guard()->check()): ?>
                <div class="card card-body mt-3">
                    <h4 class="text-center">Ubah Jadwal</h4>
                    <div class="row mt-3">
                        <div class="col-12">
                            <?php $__currentLoopData = auth()->user()->role->ibadah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ibadah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('ibadah.edit', $ibadah)); ?>" class="btn btn-secondary btn-block">
                                    Ubah Jadwal Ibadah <?php echo e($ibadah->nama); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\x\htdocs\gmahkbni\resources\views/index.blade.php ENDPATH**/ ?>