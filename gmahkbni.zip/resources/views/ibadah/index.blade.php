<x-app-layout>
    <div class="row">
        <div class="col-6 mx-auto">
            <div class="card mt-3">
                <div class="card-body">
                    <h4 class="text-center">Jadwal Ibadah</h4>
                    <div class="mt-3">
                        @foreach($ibadahs as $ibadah)
                            <a href="{{ route('ibadah.show', $ibadah) }}" class="btn btn-primary btn-block">
                                Jadwal Ibadah {{ $ibadah->nama }}
                            </a>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
